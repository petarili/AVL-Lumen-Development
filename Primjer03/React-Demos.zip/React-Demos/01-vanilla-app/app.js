﻿(function () {
    function enableSubmitButton () {
        let addTeamButtonElement = document.querySelector('.add-team-button');
        addTeamButtonElement.classList.remove('disabled');
    }
    
    function disableSubmitButton () {
        let addTeamButtonElement = document.querySelector('.add-team-button');
        let classList = addTeamButtonElement.classList;

        if (! classList.contains('disabled')) {
            classList.add('disabled');
        }
    }
    
    function addNewTeam (event) {
        event.preventDefault();
        
        let addTeamInputElement = document.querySelector('.add-team-input');
        let teamsListElement = document.querySelector('.teams');
        
        let newTeamElement = document.createElement('li')
        let newTeamElementText = document.createTextNode(addTeamInputElement.value)
        
        newTeamElement.appendChild(newTeamElementText)
        newTeamElement.classList.add('list-group-item')
        
        teamsListElement.appendChild(newTeamElement);
        
        addTeamInputElement.value = ''
        disableSubmitButton()
    }

    function validateAddTeamInput (event) {
        let addTeamButtonElement = document.querySelector('.add-team-button');
        let addTeamInputElement = document.querySelector('.add-team-input');

        if (addTeamInputElement.value.length > 0) {
            enableSubmitButton()
        } else {
            disableSubmitButton()
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        console.log('document is ready');
        
        let formElement = document.querySelector('.add-team-form');
        let addTeamInputElement = document.querySelector('.add-team-input');
        
        formElement.addEventListener('submit', addNewTeam);
        addTeamInputElement.addEventListener('keyup', validateAddTeamInput);
    })

}());
