import React from 'react';

import Header from './components/Header'
import TeamsOverview from './components/TeamsOverview'
import TeamsEditor from './components/TeamsEditor'

class App extends React.Component {
    constructor () {
        super()
        
        this.state = {
            teams: [
                '4ASa',
                'Bit by bit',
                'className O',
                'Codebrigade',
                'CodeHive Team',
            ]
        };
    }
    
    addNewTeam (teamName) {
        let teams = [...this.state.teams]
        teams.push(teamName)
        this.setState({teams: teams})
    }
    
    render () {
        return (
            <main className="container">
                <Header></Header>
                <div className="row">
                    <TeamsOverview teams={this.state.teams}></TeamsOverview>
                    <TeamsEditor onAddNewTeam={this.addNewTeam.bind(this)}></TeamsEditor>
                    
                </div>
            </main>
        );
    }
}

export default App;
