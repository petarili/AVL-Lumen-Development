﻿import React from 'react';

class Header extends React.Component {
    render () {
        return (
            <header>
                    <h1>LUMEN Development 2021 Teams</h1>
            </header>
        );
    }
}

export default Header;