﻿import React from 'react';

class TeamsOverview extends React.Component {
    constructor (props) {
        super(props)
    }
    
    renderItems () {
        const items = [];
        
        for (const [index, value] of this.props.teams.entries()) {
            items.push(<li key={index} className="list-group-item">{value}</li>);
        }
        
        return items;
    }
    
    render () {
        const items = this.renderItems()
        
        return (
            <section className="col-sm teams-container">
                <ul className="teams list-group">
                    {items}
                </ul>
            </section>
        );
    }
}

export default TeamsOverview;