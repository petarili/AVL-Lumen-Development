﻿import React from 'react';

class TeamsEditor extends React.Component {
    constructor (props) {
        super(props);
        
        this.state = {
            teamName: ''
        }
    }
    
    handleInputChange (e) {
        this.setState({
            teamName: e.target.value
        })
    }
    
    addNewTeam (e) {
        e.preventDefault()  
        this.props.onAddNewTeam(this.state.teamName)
        this.setState({teamName: ''})
    }
    
    render () {
        return (
            <section className="col-sm form-container">
                <form className="add-team-form">
                    <div className="mb-3">
                        <label htmlFor="team-name" className="form-label">Team name</label>
                        <input type="text" value={this.state.teamName} onChange={this.handleInputChange.bind(this)} className="add-team-input form-control" id="team-name"></input>
                    </div>
                    <button type="submit" className="add-team-button btn btn-primary" onClick={this.addNewTeam.bind(this)} disabled={!this.state.teamName}>Add team</button>
                </form>
            </section>
        );
    }
}

export default TeamsEditor;