function App() {
  return (
    <main className="container">
            <header>
                <h1>LUMEN Development 2021 Teams</h1>
            </header>
            <div className="row">
                <section className="col-sm teams-container">
                    <ul className="teams list-group">
                        <li className="list-group-item">4ASa</li>
                        <li className="list-group-item">Bit by bit</li>
                        <li className="list-group-item">className O</li>
                        <li className="list-group-item">Codebrigade</li>
                        <li className="list-group-item">CodeHive Team</li>
                    </ul>
                </section>
                <section className="col-sm form-container">
                    <form className="add-team-form">
                        <div className="mb-3">
                            <label for="team-name" className="form-label">Team name</label>
                            <input type="text" className="add-team-input form-control" id="team-name"></input>
                        </div>
                        <button type="submit" className="add-team-button btn btn-primary disabled">Add team</button>
                    </form>
                </section>
            </div>
        </main>
  );
}

export default App;
